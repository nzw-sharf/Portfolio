<?php

$db_host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "nzwPortfolioDb";

$con = mysqli_connect($db_host,$db_user,$db_password,$db_name) or die("Connection was not established");

$fullTitle = "Nazwa Sharaf - Full Stack Developer";
$shortTitle = "Nazwa Sharaf";

?>