<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<link rel="stylesheet" href="assets/css/bootstrap.css" />

<link rel="stylesheet" href="assets/vendors/chartjs/Chart.min.css" />
<link rel="stylesheet" href="assets/vendors/choices.js/choices.min.css" />

<link rel="stylesheet" href="assets/vendors/perfect-scrollbar/perfect-scrollbar.css" />
<link rel="stylesheet" href="assets/css/app.css" />

<link rel="shortcut icon" type="image/x-icon" href="../images/favicon.png" />
<link rel="apple-touch-icon" href="../images/favicon.png" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon.png" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon.png" />

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/sweetalert.min.js"></script>

<script>
$(document).ready(function(){
	//alert("working in head");
});
</script>