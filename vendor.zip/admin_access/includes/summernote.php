<script src="../summernote-master/dist/popper.js"></script>
<link rel="stylesheet" href="../summernote-master/dist/summernote-bs4.css" />
<script type="text/javascript" src="../summernote-master/dist/summernote-bs4.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
	  $('.summernote').summernote({
		height: 250,
		tabsize: 2
	  });
	});
</script>
