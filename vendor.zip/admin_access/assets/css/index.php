<?php
header("location: ../");
exit();
?>