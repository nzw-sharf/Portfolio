$(document).ready(function(){
	$('time.timeago').timeago();
});